import { supabase } from './lib/supabaseClient'
import { computeOverall } from './lib/playerAttributes'
import { IconCard, IconLogout, IconChevronRight } from './icons'

export default function ProfileView({ player, onNavigate }) {
  const overall = computeOverall(player.attributes)

  return (
    <div className="profile-view">
      <div className="profile-header">
        <div className="profile-mini-badge">
          <span className="profile-mini-jersey">{player.jersey_number ?? '-'}</span>
          <span className="profile-mini-overall">{overall}</span>
        </div>
        <div>
          <p className="profile-name">{player.name}</p>
          <p className="profile-subtitle">Futsal Kings</p>
        </div>
      </div>

      <ul className="profile-list">
        <li>
          <button className="profile-list-item" onClick={() => onNavigate('cartinha')}>
            <IconCard size={20} />
            <span>Minha cartinha</span>
            <IconChevronRight size={18} />
          </button>
        </li>
        <li>
          <button className="profile-list-item" onClick={() => supabase.auth.signOut()}>
            <IconLogout size={20} />
            <span>Sair</span>
          </button>
        </li>
      </ul>

      <p className="profile-footer">Futsal Kings</p>
    </div>
  )
}
