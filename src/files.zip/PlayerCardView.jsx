import { useState } from 'react'
import { supabase } from './lib/supabaseClient'
import Crest from './Crest'
import { ATTRIBUTE_LABELS, ATTRIBUTE_ORDER, computeOverall } from './lib/playerAttributes'

export default function PlayerCardView({ player, onPlayerUpdated }) {
  const [draftAttributes, setDraftAttributes] = useState(() => ({ ...player.attributes }))
  const [draftPoints, setDraftPoints] = useState(player.skill_points_available)
  const [saving, setSaving] = useState(false)
  const [status, setStatus] = useState(null)

  const hasChanges = draftPoints !== player.skill_points_available

  function increment(attr) {
    if (draftPoints <= 0 || draftAttributes[attr] >= 99) return
    setDraftAttributes((prev) => ({ ...prev, [attr]: prev[attr] + 1 }))
    setDraftPoints((prev) => prev - 1)
  }

  function decrement(attr) {
    if (draftAttributes[attr] <= (player.attributes[attr] ?? 40)) return
    setDraftAttributes((prev) => ({ ...prev, [attr]: prev[attr] - 1 }))
    setDraftPoints((prev) => prev + 1)
  }

  async function handleSave() {
    setSaving(true)
    setStatus(null)

    const { data, error } = await supabase
      .from('players')
      .update({ attributes: draftAttributes, skill_points_available: draftPoints })
      .eq('id', player.id)
      .select('id, name, jersey_number, total_points, skill_points_available, attributes, is_admin, user_id')
      .single()

    if (error) {
      setStatus({ type: 'error', message: `Erro ao salvar: ${error.message}` })
    } else {
      onPlayerUpdated(data)
      setStatus({ type: 'success', message: 'Cartinha atualizada!' })
    }
    setSaving(false)
  }

  const overall = computeOverall(draftAttributes)

  return (
    <div className="card-view">
      <div className="player-card">
        <div className="player-card-top">
          <div className="player-card-top-left">
            <Crest size={22} className="player-card-crest" />
            <span className="player-card-overall">{overall}</span>
          </div>
          <span className="player-card-jersey">{player.jersey_number ?? '-'}</span>
        </div>
        <h2 className="player-card-name">{player.name}</h2>

        <div className="attribute-list">
          {ATTRIBUTE_ORDER.map((attr) => (
            <div className="attribute-row" key={attr}>
              <span className="attribute-label">{ATTRIBUTE_LABELS[attr]}</span>
              <div className="attribute-bar-track">
                <div className="attribute-bar-fill" style={{ width: `${draftAttributes[attr]}%` }} />
              </div>
              <span className="attribute-value">{draftAttributes[attr]}</span>
              <div className="attribute-controls">
                <button
                  type="button"
                  onClick={() => decrement(attr)}
                  disabled={draftAttributes[attr] <= (player.attributes[attr] ?? 40)}
                  aria-label={`Diminuir ${ATTRIBUTE_LABELS[attr]}`}
                >
                  −
                </button>
                <button
                  type="button"
                  onClick={() => increment(attr)}
                  disabled={draftPoints <= 0 || draftAttributes[attr] >= 99}
                  aria-label={`Aumentar ${ATTRIBUTE_LABELS[attr]}`}
                >
                  +
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <p className="points-available">
        Pontos disponíveis pra distribuir: <strong>{draftPoints}</strong>
      </p>

      {status && <p className={`status-message status-${status.type}`}>{status.message}</p>}

      <button className="save-button" onClick={handleSave} disabled={saving || !hasChanges}>
        {saving ? 'Salvando…' : 'Salvar distribuição'}
      </button>
    </div>
  )
}
