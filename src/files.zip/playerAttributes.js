export const ATTRIBUTE_LABELS = {
  pace: 'Ritmo',
  shooting: 'Finalização',
  passing: 'Passe',
  dribbling: 'Drible',
  defending: 'Defesa',
  physical: 'Físico',
}

export const ATTRIBUTE_ORDER = ['pace', 'shooting', 'passing', 'dribbling', 'defending', 'physical']

export function computeOverall(attributes) {
  const values = ATTRIBUTE_ORDER.map((key) => attributes?.[key] ?? 40)
  const average = values.reduce((sum, v) => sum + v, 0) / values.length
  return Math.round(average)
}
